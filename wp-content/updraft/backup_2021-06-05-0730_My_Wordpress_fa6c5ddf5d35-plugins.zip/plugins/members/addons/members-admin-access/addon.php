<?php

require_once( 'bootstrap/app.php' );
